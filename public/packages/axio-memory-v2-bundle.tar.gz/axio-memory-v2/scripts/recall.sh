#!/bin/bash
# Axio Engineering - Cortical Recall v2 (Tri-Tier Architecture)
# Layers: Qdrant (Index) -> SQLite (Cache) -> Console

QUERY="$1"
if [ -z "$QUERY" ]; then
  echo "Usage: recall <query>"
  exit 1
fi

DB_PATH="/var/home/motto/Documentos/REPO/axiomatic-nest/data/axiomatic-nest.sqlite"
COLLECTION="openclaw_memory"
OLLAMA_URL="http://127.0.0.1:11434"
QDRANT_URL="http://127.0.0.1:6333"

# 1. Generate embedding using Ollama
VECTOR=$(curl -s $OLLAMA_URL/api/embeddings -d "{
  \"model\": \"nomic-embed-text:latest\",
  \"prompt\": \"$(echo $QUERY | sed 's/"/\\"/g')\"
}" | jq -c '.embedding')

if [ -z "$VECTOR" ] || [ "$VECTOR" == "null" ]; then
  echo "Error: Failed to generate embedding"
  exit 1
fi

# 2. Search Qdrant for semantic pointers
# Returns a JSON array of {id, score, source, path}
RESULTS=$(curl -s -X POST $QDRANT_URL/collections/$COLLECTION/points/search -d "{
  \"vector\": $VECTOR,
  \"limit\": 5,
  \"with_payload\": true,
  \"score_threshold\": 0.1
}" | jq -c '.result | map({id: .id, score: .score, source: (.payload.source // .payload.path // "Unknown")})')

if [ "$RESULTS" == "[]" ] || [ -z "$RESULTS" ]; then
  echo "Nenhuma memória relevante encontrada no Cortical Stack."
  exit 0
fi

echo "--- [CORTICAL RECALL (v2): $(echo $QUERY | tr '[:lower:]' '[:upper:]')] ---"

# 3. Resolve content from SQLite cache
echo "$RESULTS" | jq -c '.[]' | while read -r res; do
  ID=$(echo "$res" | jq -r '.id')
  SCORE=$(echo "$res" | jq -r '.score')
  SOURCE=$(echo "$res" | jq -r '.source')
  
  # Fetch from SQLite
  CONTENT=$(sqlite3 "$DB_PATH" "SELECT content FROM memory_cache WHERE id = '$ID';" 2>/dev/null)
  
  # Fallback: if not in SQLite, check if content is still in Qdrant payload (legacy points)
  if [ -z "$CONTENT" ]; then
     CONTENT=$(curl -s $QDRANT_URL/collections/$COLLECTION/points/$ID | jq -r '.result.payload.content // .result.payload.text // ""')
  fi

  if [ -n "$CONTENT" ]; then
    echo -e "\n[Score: $SCORE] | Source: $SOURCE"
    echo "Content: $CONTENT"
    echo "---------------------------------------------------"
  fi
done

echo -e "\n--- END RECALL ---"
