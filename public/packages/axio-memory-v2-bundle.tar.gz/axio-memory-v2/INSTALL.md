# Axio Memory v2 (Tri-Tier Architecture) - Installation Guide

This package contains the core components of the **Axio Engineering Tri-Tier Memory System**.

## 🏗️ Architecture
1. **Tier 1 (Authority):** Local Markdown files versioned via Git.
2. **Tier 2 (Cache):** SQLite database for fast textual retrieval (<1ms).
3. **Tier 3 (Index):** Qdrant Vector Database for semantic search (Index-only).

## 📦 Contents
- `src/`: NestJS backend source code.
- `Dockerfile`: Multi-stage build for Podman/Docker.
- `scripts/recall.sh`: CLI tool for semantic memory retrieval.
- `data_seed.sqlite`: Initial cache seed.

## 🚀 Setup for Other Agents

1. **Deploy Backend:**
   ```bash
   podman build -t axio-memory-v2 .
   podman run -d --name axio-nest -p 3002:3002 axio-memory-v2
   ```

2. **Initialize Databases:**
   - Ensure Qdrant is running on port 6333.
   - Run `npx ts-node reingest.ts` to sync Tier 1 to Tiers 2 & 3.

3. **Install Recall Skill:**
   - Copy `scripts/recall.sh` to your local bin.
   - Configure `OLLAMA_URL` and `QDRANT_URL` environment variables.

## 🛡️ Security
- All skills must be verified via the **Skill Manifest** protocol (SHA-256).
- Use **Thermal Watchdogs** if running intensive weaving cycles.

---
*Property of Axio Engineering. Sovereignty through Data.* 🧪🧬
