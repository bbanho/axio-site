import { Test, TestingModule } from '@nestjs/testing';
import { OllamaService } from './ollama.service';
import axios from 'axios';

jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe('OllamaService', () => {
  let service: OllamaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [OllamaService],
    }).compile();

    service = module.get<OllamaService>(OllamaService);
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('embed', () => {
    it('should return embedding vector successfully', async () => {
      const mockEmbedding = [0.1, 0.2, 0.3];
      mockedAxios.post.mockResolvedValueOnce({
        data: { embedding: mockEmbedding },
      });

      const result = await service.embed('test text');
      expect(result).toEqual(mockEmbedding);
      expect(mockedAxios.post).toHaveBeenCalledWith(
        expect.stringContaining('/api/embeddings'),
        {
          model: 'nomic-embed-text',
          prompt: 'test text',
        },
      );
    });

    it('should throw error on failure', async () => {
      mockedAxios.post.mockRejectedValueOnce(new Error('Network Error'));
      await expect(service.embed('test')).rejects.toThrow('Ollama Embed Error');
    });
  });

  describe('chat', () => {
    it('should return chat response successfully', async () => {
      const mockResponse = 'Hello there!';
      mockedAxios.post.mockResolvedValueOnce({
        data: { message: { content: mockResponse } },
      });

      const messages = [{ role: 'user', content: 'hi' }];
      const options = { model: 'llama3' };

      const result = await service.chat(messages, options);
      expect(result).toEqual(mockResponse);
      expect(mockedAxios.post).toHaveBeenCalledWith(
        expect.stringContaining('/api/chat'),
        expect.objectContaining({
          model: 'llama3',
          messages,
          stream: false,
        }),
      );
    });

    it('should throw error on failure', async () => {
      mockedAxios.post.mockRejectedValueOnce(new Error('API Error'));
      await expect(service.chat([], { model: 'test' })).rejects.toThrow(
        'Ollama Chat Error',
      );
    });
  });
});
