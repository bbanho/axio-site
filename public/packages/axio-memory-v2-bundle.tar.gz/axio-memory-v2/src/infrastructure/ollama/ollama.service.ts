import { Injectable, Logger } from '@nestjs/common';
import axios from 'axios';

@Injectable()
export class OllamaService {
  private readonly baseUrl = process.env.OLLAMA_URL || 'http://127.0.0.1:11434';
  private readonly logger = new Logger(OllamaService.name);

  async embed(
    text: string,
    model = 'nomic-embed-text',
  ): Promise<number[] | null> {
    return this.retry(async () => {
      const res = await axios.post(`${this.baseUrl}/api/embeddings`, {
        model,
        prompt: text,
      });
      return res.data.embedding;
    }, 'Embed');
  }

  async chat(
    messages: { role: string; content: string }[],
    options: { model: string; temperature?: number; num_ctx?: number },
  ): Promise<string | null> {
    return this.retry(async () => {
      const res = await axios.post(`${this.baseUrl}/api/chat`, {
        model: options.model,
        messages,
        stream: false,
        options: {
          temperature: options.temperature,
          num_ctx: options.num_ctx,
        },
      });
      return res.data.message.content;
    }, 'Chat');
  }

  private async retry<T>(
    fn: () => Promise<T>,
    operation: string,
    retries = 3,
    delay = 2000,
  ): Promise<T | null> {
    try {
      return await fn();
    } catch (e) {
      if (retries > 0) {
        const errorMsg = e instanceof Error ? e.message : String(e);
        this.logger.warn(
          `Ollama ${operation} failed (${errorMsg}). Retrying in ${delay}ms... (${retries} left)`,
        );
        await new Promise((resolve) => setTimeout(resolve, delay));
        return this.retry(fn, operation, retries - 1, delay * 2);
      }
      this.logger.warn(
        `Ollama ${operation} unavailable after retries. Reducing noise.`,
      );
      return null;
    }
  }
}
