import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { MemoryCache } from '../../domain/entities/memory-cache.entity';

@Injectable()
export class MemoryCacheService {
  constructor(
    @InjectRepository(MemoryCache)
    private readonly memoryCacheRepository: Repository<MemoryCache>,
  ) {}

  async store(
    id: string,
    content: string,
    path?: string,
    source?: string,
  ): Promise<MemoryCache> {
    const memoryCache = this.memoryCacheRepository.create({
      id,
      content,
      path,
      source,
    });

    return this.memoryCacheRepository.save(memoryCache);
  }

  async findById(id: string): Promise<MemoryCache | null> {
    return this.memoryCacheRepository.findOne({ where: { id } });
  }

  async findByPath(path: string): Promise<MemoryCache[]> {
    return this.memoryCacheRepository.find({ where: { path } });
  }

  async findBySource(source: string): Promise<MemoryCache[]> {
    return this.memoryCacheRepository.find({ where: { source } });
  }

  async deleteById(id: string): Promise<void> {
    await this.memoryCacheRepository.delete(id);
  }

  async updateById(
    id: string,
    updates: Partial<MemoryCache>,
  ): Promise<MemoryCache> {
    await this.memoryCacheRepository.update(id, updates);
    const updated = await this.findById(id);
    if (!updated) {
      throw new Error(`MemoryCache with id ${id} not found after update`);
    }
    return updated;
  }

  async listAll(limit: number = 100): Promise<MemoryCache[]> {
    return this.memoryCacheRepository.find({
      take: limit,
      order: { createdAt: 'DESC' },
    });
  }

  async searchContent(
    query: string,
    limit: number = 10,
  ): Promise<MemoryCache[]> {
    return this.memoryCacheRepository
      .createQueryBuilder('memoryCache')
      .where('memoryCache.content LIKE :query', { query: `%${query}%` })
      .orderBy('memoryCache.createdAt', 'DESC')
      .take(limit)
      .getMany();
  }
}
