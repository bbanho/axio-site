import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MemoryCache } from '../../domain/entities/memory-cache.entity';
import { MemoryCacheService } from './memory-cache.service';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'sqlite',
      database: process.env.DATABASE_PATH || './data/axiomatic-nest.sqlite',
      entities: [MemoryCache],
      synchronize: process.env.NODE_ENV !== 'production',
      logging: process.env.NODE_ENV === 'development',
    }),
    TypeOrmModule.forFeature([MemoryCache]),
  ],
  providers: [MemoryCacheService],
  exports: [MemoryCacheService],
})
export class DatabaseModule {}
