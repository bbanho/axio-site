import { Module } from '@nestjs/common';
import { MemoryFileSystemService } from './filesystem.service';
import { QdrantModule } from '../../qdrant/qdrant.module';

@Module({
  imports: [QdrantModule],
  providers: [MemoryFileSystemService],
  exports: [MemoryFileSystemService],
})
export class MemoryFileSystemModule {}
