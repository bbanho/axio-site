export interface VirtualFile {
  id: string;
  name: string;
  type: 'file';
  content: any;
  payload: any;
  createdAt: Date;
  updatedAt: Date;
}

export interface VirtualFolder {
  id: string;
  name: string;
  type: 'folder';
  path: string;
  parentId?: string;
  createdAt: Date;
  updatedAt: Date;
}

export type VirtualNode = VirtualFile | VirtualFolder;

export interface FileSystemPath {
  parts: string[];
  fullPath: string;
}

export interface LsResult {
  files: VirtualFile[];
  folders: VirtualFolder[];
}

export interface ReadResult {
  content: any;
  metadata: any;
}
