import { Injectable, OnModuleInit } from '@nestjs/common';
import { QdrantService } from '../../qdrant/qdrant.service';
import { v4 as uuidv4 } from 'uuid';
import {
  VirtualFile,
  VirtualFolder,
  VirtualNode,
  FileSystemPath,
  LsResult,
  ReadResult,
} from './interfaces/filesystem.interfaces';

@Injectable()
export class MemoryFileSystemService implements OnModuleInit {
  constructor(private readonly qdrantService: QdrantService) {}

  async onModuleInit() {
    await this.ensureRootFolder();
    await this.ensureDefaultFolders();
  }

  private async ensureDefaultFolders(): Promise<void> {
    const defaultFolders = ['/raw', '/refined', '/processed'];

    for (const folderPath of defaultFolders) {
      if (!(await this.folderExists(folderPath))) {
        await this.mkdir(folderPath);
      }
    }
  }

  private async ensureRootFolder(): Promise<void> {
    const rootFilter = {
      must: [
        { key: 'type', match: { value: 'folder' } },
        { key: 'path', match: { value: '/' } },
      ],
    };

    const existingRoot = await this.qdrantService.scroll(rootFilter, 1);

    if (existingRoot.length === 0) {
      const rootFolder: VirtualFolder = {
        id: uuidv4(),
        name: 'root',
        type: 'folder',
        path: '/',
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      await this.qdrantService.upsert([
        {
          id: rootFolder.id,
          vector: new Array(768).fill(0),
          payload: {
            ...rootFolder,
            category: 'filesystem',
          },
        },
      ]);
    }
  }

  parsePath(path: string): FileSystemPath {
    const normalizedPath = path.replace(/\\/g, '/').replace(/\/+/g, '/');
    const parts = normalizedPath.split('/').filter((part) => part.length > 0);
    return {
      parts,
      fullPath: normalizedPath.startsWith('/')
        ? normalizedPath
        : `/${normalizedPath}`,
    };
  }

  async mkdir(path: string): Promise<VirtualFolder> {
    const { parts, fullPath } = this.parsePath(path);

    if (parts.length === 0) {
      throw new Error('Cannot create root folder');
    }

    const parentPath = '/' + parts.slice(0, -1).join('/');
    const folderName = parts[parts.length - 1];

    if (await this.folderExists(fullPath)) {
      throw new Error(`Folder already exists: ${fullPath}`);
    }

    if (!(await this.folderExists(parentPath))) {
      await this.mkdir(parentPath);
    }

    const parentFolder = await this.getFolder(parentPath);

    const newFolder: VirtualFolder = {
      id: uuidv4(),
      name: folderName,
      type: 'folder',
      path: fullPath,
      parentId: parentFolder?.id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    await this.qdrantService.upsert([
      {
        id: newFolder.id,
        vector: new Array(768).fill(0),
        payload: {
          ...newFolder,
          category: 'filesystem',
        },
      },
    ]);

    return newFolder;
  }

  async ls(path: string = '/'): Promise<LsResult> {
    const { fullPath } = this.parsePath(path);

    if (!(await this.folderExists(fullPath))) {
      throw new Error(`Folder not found: ${fullPath}`);
    }

    const folder = await this.getFolder(fullPath);

    const childrenFilter = {
      must: [
        { key: 'category', match: { value: 'filesystem' } },
        { key: 'parentId', match: { value: folder?.id } },
      ],
      must_not: [{ key: 'deleted', match: { value: true } }],
    };

    const children = await this.qdrantService.scroll(childrenFilter, 1000);

    const files: VirtualFile[] = [];
    const folders: VirtualFolder[] = [];

    children.forEach((child) => {
      const node = child.payload as VirtualNode;
      if (node.type === 'file') {
        files.push(node);
      } else if (node.type === 'folder') {
        folders.push(node);
      }
    });

    return { files, folders };
  }

  async read(path: string): Promise<ReadResult> {
    const { fullPath } = this.parsePath(path);

    const fileFilter = {
      must: [
        { key: 'type', match: { value: 'file' } },
        { key: 'path', match: { value: fullPath } },
      ],
      must_not: [{ key: 'deleted', match: { value: true } }],
    };

    const files = await this.qdrantService.scroll(fileFilter, 1);

    if (files.length === 0) {
      throw new Error(`File not found: ${fullPath}`);
    }

    const file = files[0].payload as VirtualFile;

    return {
      content: file.content,
      metadata: {
        id: file.id,
        name: file.name,
        createdAt: file.createdAt,
        updatedAt: file.updatedAt,
        payload: file.payload,
      },
    };
  }

  async writeFile(
    path: string,
    content: any,
    payload?: any,
  ): Promise<VirtualFile> {
    const { parts, fullPath } = this.parsePath(path);

    if (parts.length === 0) {
      throw new Error('Invalid file path');
    }

    const parentPath = '/' + parts.slice(0, -1).join('/');
    const fileName = parts[parts.length - 1];

    if (!(await this.folderExists(parentPath))) {
      await this.mkdir(parentPath);
    }

    const existingFile = await this.getFile(fullPath);
    const parentFolder = await this.getFolder(parentPath);

    const file: VirtualFile = {
      id: existingFile?.id || uuidv4(),
      name: fileName,
      type: 'file',
      content,
      payload: payload || {},
      createdAt: existingFile?.createdAt || new Date(),
      updatedAt: new Date(),
    };

    await this.qdrantService.upsert([
      {
        id: file.id,
        vector: new Array(768).fill(0),
        payload: {
          ...file,
          path: fullPath,
          parentId: parentFolder?.id,
          category: 'filesystem',
        },
      },
    ]);

    return file;
  }

  async folderExists(path: string): Promise<boolean> {
    const { fullPath } = this.parsePath(path);

    const folderFilter = {
      must: [
        { key: 'type', match: { value: 'folder' } },
        { key: 'path', match: { value: fullPath } },
      ],
      must_not: [{ key: 'deleted', match: { value: true } }],
    };

    const folders = await this.qdrantService.scroll(folderFilter, 1);
    return folders.length > 0;
  }

  async fileExists(path: string): Promise<boolean> {
    const { fullPath } = this.parsePath(path);

    const fileFilter = {
      must: [
        { key: 'type', match: { value: 'file' } },
        { key: 'path', match: { value: fullPath } },
      ],
      must_not: [{ key: 'deleted', match: { value: true } }],
    };

    const files = await this.qdrantService.scroll(fileFilter, 1);
    return files.length > 0;
  }

  private async getFolder(path: string): Promise<VirtualFolder | null> {
    const { fullPath } = this.parsePath(path);

    const folderFilter = {
      must: [
        { key: 'type', match: { value: 'folder' } },
        { key: 'path', match: { value: fullPath } },
      ],
      must_not: [{ key: 'deleted', match: { value: true } }],
    };

    const folders = await this.qdrantService.scroll(folderFilter, 1);
    return folders.length > 0 ? (folders[0].payload as VirtualFolder) : null;
  }

  private async getFile(path: string): Promise<VirtualFile | null> {
    const { fullPath } = this.parsePath(path);

    const fileFilter = {
      must: [
        { key: 'type', match: { value: 'file' } },
        { key: 'path', match: { value: fullPath } },
      ],
      must_not: [{ key: 'deleted', match: { value: true } }],
    };

    const files = await this.qdrantService.scroll(fileFilter, 1);
    return files.length > 0 ? (files[0].payload as VirtualFile) : null;
  }

  async write(path: string, content: any, payload?: any): Promise<VirtualFile> {
    return this.writeFile(path, content, payload);
  }

  async delete(path: string): Promise<void> {
    const { fullPath } = this.parsePath(path);

    const nodeFilter = {
      must: [
        { key: 'category', match: { value: 'filesystem' } },
        { key: 'path', match: { value: fullPath } },
      ],
    };

    const nodes = await this.qdrantService.scroll(nodeFilter, 1);

    if (nodes.length === 0) {
      throw new Error(`Path not found: ${fullPath}`);
    }

    const node = nodes[0].payload as VirtualNode;

    if (node.type === 'folder') {
      const childrenFilter = {
        must: [
          { key: 'category', match: { value: 'filesystem' } },
          { key: 'parentId', match: { value: node.id } },
        ],
      };

      const children = await this.qdrantService.scroll(childrenFilter, 1000);

      for (const child of children) {
        const childNode = child.payload as VirtualNode;
        if (childNode.type === 'folder') {
          await this.delete(childNode.path);
        }
      }
    }

    await this.qdrantService.updatePayload(
      { must: [{ key: 'id', match: { value: node.id } }] },
      { deleted: true, deletedAt: new Date() },
    );
  }
}
