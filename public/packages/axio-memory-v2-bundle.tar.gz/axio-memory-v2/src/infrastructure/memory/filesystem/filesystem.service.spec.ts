import { Test, TestingModule } from '@nestjs/testing';
import { MemoryFileSystemService } from './filesystem.service';
import { QdrantService } from '../../qdrant/qdrant.service';

describe('MemoryFileSystemService', () => {
  let service: MemoryFileSystemService;

  const mockQdrantService = {
    scroll: jest.fn(),
    upsert: jest.fn(),
    updatePayload: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MemoryFileSystemService,
        {
          provide: QdrantService,
          useValue: mockQdrantService,
        },
      ],
    }).compile();

    service = module.get<MemoryFileSystemService>(MemoryFileSystemService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('parsePath', () => {
    it('should parse simple path', () => {
      const result = service.parsePath('folder/file');
      expect(result.parts).toEqual(['folder', 'file']);
      expect(result.fullPath).toBe('/folder/file');
    });

    it('should parse absolute path', () => {
      const result = service.parsePath('/folder/file');
      expect(result.parts).toEqual(['folder', 'file']);
      expect(result.fullPath).toBe('/folder/file');
    });

    it('should normalize path separators', () => {
      const result = service.parsePath('folder\\\\file');
      expect(result.parts).toEqual(['folder', 'file']);
      expect(result.fullPath).toBe('/folder/file');
    });
  });

  describe('mkdir', () => {
    beforeEach(() => {
      mockQdrantService.scroll.mockResolvedValue([]);
      mockQdrantService.upsert.mockResolvedValue({});
    });

    it('should create a folder', async () => {
      const folder = await service.mkdir('/test');

      expect(folder.name).toBe('test');
      expect(folder.path).toBe('/test');
      expect(folder.type).toBe('folder');
      expect(mockQdrantService.upsert).toHaveBeenCalled();
    });

    it('should throw error for root folder creation', async () => {
      await expect(service.mkdir('/')).rejects.toThrow(
        'Cannot create root folder',
      );
    });

    it('should create nested folders', async () => {
      mockQdrantService.scroll
        .mockResolvedValueOnce([]) // root check
        .mockResolvedValueOnce([]) // parent check
        .mockResolvedValueOnce([{ payload: { id: 'root-id' } }]) // get root
        .mockResolvedValueOnce([]); // new folder check

      await service.mkdir('/test/nested');

      expect(mockQdrantService.upsert).toHaveBeenCalledTimes(2);
    });
  });

  describe('ls', () => {
    beforeEach(() => {
      const mockRootFolder = {
        payload: {
          id: 'root-id',
          type: 'folder',
          name: 'root',
          path: '/',
        },
      };

      const mockChildren = [
        {
          payload: {
            id: 'file-1',
            type: 'file',
            name: 'file1.txt',
            content: 'test content',
          },
        },
        {
          payload: {
            id: 'folder-1',
            type: 'folder',
            name: 'folder1',
            path: '/folder1',
          },
        },
      ];

      mockQdrantService.scroll
        .mockResolvedValueOnce([mockRootFolder]) // folder check
        .mockResolvedValueOnce([mockRootFolder]) // get folder
        .mockResolvedValueOnce(mockChildren); // children
    });

    it('should list folder contents', async () => {
      const result = await service.ls('/');

      expect(result.files).toHaveLength(1);
      expect(result.folders).toHaveLength(1);
      expect(result.files[0].name).toBe('file1.txt');
      expect(result.folders[0].name).toBe('folder1');
    });

    it('should throw error for non-existent folder', async () => {
      mockQdrantService.scroll.mockResolvedValue([]);

      await expect(service.ls('/nonexistent')).rejects.toThrow(
        'Folder not found',
      );
    });
  });

  describe('read', () => {
    it('should read file content', async () => {
      const mockFile = {
        payload: {
          id: 'file-1',
          type: 'file',
          name: 'test.txt',
          content: 'Hello World',
          payload: { extra: 'data' },
        },
      };

      mockQdrantService.scroll.mockResolvedValue([mockFile]);

      const result = await service.read('/test.txt');

      expect(result.content).toBe('Hello World');
      expect(result.metadata.id).toBe('file-1');
      expect(result.metadata.payload.extra).toBe('data');
    });

    it('should throw error for non-existent file', async () => {
      mockQdrantService.scroll.mockResolvedValue([]);

      await expect(service.read('/nonexistent.txt')).rejects.toThrow(
        'File not found',
      );
    });
  });

  describe('writeFile', () => {
    beforeEach(() => {
      const mockRootFolder = {
        payload: {
          id: 'root-id',
          type: 'folder',
          name: 'root',
          path: '/',
        },
      };

      mockQdrantService.scroll
        .mockResolvedValue([mockRootFolder]) // parent folder check
        .mockResolvedValue([]); // existing file check
      mockQdrantService.upsert.mockResolvedValue({});
    });

    it('should write a new file', async () => {
      const file = await service.writeFile('/test.txt', 'Hello World', {
        tag: 'test',
      });

      expect(file.name).toBe('test.txt');
      expect(file.content).toBe('Hello World');
      expect(file.payload.tag).toBe('test');
      expect(mockQdrantService.upsert).toHaveBeenCalled();
    });
  });
});
