import { Injectable, OnModuleInit } from '@nestjs/common';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class QdrantService implements OnModuleInit {
  private readonly baseUrl = process.env.QDRANT_URL || 'http://127.0.0.1:6333';
  private readonly collection = 'openclaw_memory';

  /**
   * Initializes the module by ensuring the Qdrant collection exists.
   */
  async onModuleInit() {
    await this.ensureCollection();
  }

  /**
   * Checks if the configured collection exists; creates it if it does not.
   * Uses cosine distance and a vector size of 768 by default.
   */
  async ensureCollection() {
    try {
      await axios.get(`${this.baseUrl}/collections/${this.collection}`);
    } catch {
      console.log(`Creating collection ${this.collection}...`);
      await axios.put(`${this.baseUrl}/collections/${this.collection}`, {
        vectors: { size: 768, distance: 'Cosine' },
      });
    }
  }

  /**
   * Upserts points (vectors + payload) into the collection.
   * @param points - Array of points to insert or update.
   */
  async upsert(points: any[]) {
    await axios.put(`${this.baseUrl}/collections/${this.collection}/points`, {
      points,
    });
  }

  /**
   * Scrolls through points in the collection based on a filter.
   * Useful for listing or paginating data.
   * @param filter - Qdrant filter object.
   * @param limit - Max number of points to return (default: 10).
   * @returns Array of points.
   */
  async scroll(filter: any, limit = 10): Promise<any[]> {
    const res = await axios.post(
      `${this.baseUrl}/collections/${this.collection}/points/scroll`,
      {
        filter,
        limit,
        with_payload: true,
        with_vector: true,
      },
    );
    return res.data.result.points;
  }

  /**
   * Searches for nearest neighbors using a vector similarity search.
   * @param vector - The query embedding vector.
   * @param filter - Optional filter to restrict search scope.
   * @param limit - Max number of results (default: 5).
   * @returns Array of scored points.
   */
  async search(vector: number[], filter: any, limit = 5): Promise<any[]> {
    const res = await axios.post(
      `${this.baseUrl}/collections/${this.collection}/points/search`,
      {
        vector,
        filter,
        limit,
        with_payload: true,
      },
    );
    return res.data.result;
  }

  /**
   * Updates the payload of points matching the filter.
   * @param filter - Filter to select target points.
   * @param payload - Data to merge into existing payloads.
   */
  async updatePayload(filter: any, payload: any) {
    await axios.post(
      `${this.baseUrl}/collections/${this.collection}/points/payload`,
      {
        filter,
        payload,
      },
    );
  }

  /**
   * Generates a unique UUID v4.
   * @returns UUID string.
   */
  generateId(): string {
    return uuidv4();
  }
}
