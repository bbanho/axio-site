import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { OllamaModule } from './infrastructure/ollama/ollama.module';
import { QdrantModule } from './infrastructure/qdrant/qdrant.module';
import { MemoryFileSystemModule } from './infrastructure/memory/filesystem/filesystem.module';
import { DatabaseModule } from './infrastructure/database/database.module';
import { CortexModule } from './application/cortex/cortex.module';
import { IngestionModule } from './application/ingestion/ingestion.module';
import { GraphController } from './application/api/graph/graph.controller';
import { FileSystemModule } from './application/api/filesystem/filesystem.module';

@Module({
  imports: [
    ScheduleModule.forRoot(),
    DatabaseModule,
    OllamaModule,
    QdrantModule,
    MemoryFileSystemModule,
    FileSystemModule,
    CortexModule,
    IngestionModule,
  ],
  controllers: [AppController, GraphController],
  providers: [AppService],
})
export class AppModule {}
