import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { MemoryFileSystemService } from '../../../infrastructure/memory/filesystem/filesystem.service';

@Controller('memory/filesystem')
export class FileSystemController {
  constructor(private readonly fileSystemService: MemoryFileSystemService) {}

  @Post('mkdir')
  async mkdir(@Body('path') path: string) {
    try {
      const folder = await this.fileSystemService.mkdir(path);
      return {
        success: true,
        data: folder,
      };
    } catch (error) {
      throw new HttpException(
        (error as Error).message || 'Failed to create directory',
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  @Get('ls')
  async lsRoot() {
    return this.ls('/');
  }

  @Get('ls/*path')
  async ls(@Param('path') path: string | string[]) {
    try {
      const actualPath = Array.isArray(path) ? path.join('/') : path || '/';
      const result = await this.fileSystemService.ls(actualPath);
      return {
        success: true,
        data: result,
      };
    } catch (error) {
      throw new HttpException(
        (error as Error).message || 'Failed to list directory',
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  @Get('read/*path')
  async read(@Param('path') path: string | string[]) {
    try {
      const actualPath = Array.isArray(path) ? path.join('/') : path;
      const result = await this.fileSystemService.read('/' + actualPath);
      return {
        success: true,
        data: result,
      };
    } catch (error) {
      throw new HttpException(
        (error as Error).message || 'Failed to read file',
        HttpStatus.NOT_FOUND,
      );
    }
  }

  @Post('write')
  async write(
    @Body('path') path: string,
    @Body('content') content: any,
    @Body('payload') payload?: any,
  ) {
    try {
      const file = await this.fileSystemService.writeFile(
        path,
        content,
        payload,
      );
      return {
        success: true,
        data: file,
      };
    } catch (error) {
      throw new HttpException(
        (error as Error).message || 'Failed to write file',
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  @Delete('delete/*path')
  async delete(@Param('path') path: string | string[]) {
    try {
      const actualPath = Array.isArray(path) ? path.join('/') : path;
      await this.fileSystemService.delete('/' + actualPath);
      return {
        success: true,
        message: 'Path deleted successfully',
      };
    } catch (error) {
      throw new HttpException(
        (error as Error).message || 'Failed to delete path',
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  @Get('exists/file/*path')
  async fileExists(@Param('path') path: string | string[]) {
    const actualPath = Array.isArray(path) ? path.join('/') : path;
    const exists = await this.fileSystemService.fileExists('/' + actualPath);
    return {
      success: true,
      data: { exists, path: '/' + actualPath, type: 'file' },
    };
  }

  @Get('exists/folder/*path')
  async folderExists(@Param('path') path: string | string[]) {
    const actualPath = Array.isArray(path) ? path.join('/') : path;
    const exists = await this.fileSystemService.folderExists('/' + actualPath);
    return {
      success: true,
      data: { exists, path: '/' + actualPath, type: 'folder' },
    };
  }
}
