import { Module } from '@nestjs/common';
import { FileSystemController } from './filesystem.controller';
import { MemoryFileSystemModule } from '../../../infrastructure/memory/filesystem/filesystem.module';

@Module({
  imports: [MemoryFileSystemModule],
  controllers: [FileSystemController],
})
export class FileSystemModule {}
