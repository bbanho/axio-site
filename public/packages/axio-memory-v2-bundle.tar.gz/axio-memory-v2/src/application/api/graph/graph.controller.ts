import { Controller, Get, Post } from '@nestjs/common';
import { QdrantService } from '../../../infrastructure/qdrant/qdrant.service';
import { IngestionService } from '../../ingestion/ingestion.service';
import { WeaverService } from '../../cortex/weaver/weaver.service';

@Controller('api/graph')
export class GraphController {
  constructor(
    private readonly qdrant: QdrantService,
    private readonly ingestion: IngestionService,
    private readonly weaver: WeaverService,
  ) {}

  @Post('ingest')
  async triggerIngest() {
    await this.ingestion.ingestAll();
    return { status: 'ingestion_triggered' };
  }

  @Post('weave')
  async triggerWeave() {
    await this.weaver.runWeaverCycle();
    return { status: 'weaving_cycle_triggered' };
  }

  @Get()
  async getGraph() {
    const points = await this.qdrant.scroll({}, 1000);

    // Transform to Hypothesis format
    const nodes = points.map((pt) => ({
      id: pt.id,
      name: (pt.payload.name || pt.payload.context || 'Unknown').slice(0, 50),
      type: 'service',
      group: pt.payload.category || 'raw',
      isExperimental: false,
      attributes: [
        pt.payload.content?.slice(0, 100) ||
          pt.payload.text?.slice(0, 100) ||
          '',
      ],
    }));

    const links: any[] = [];
    points.forEach((pt) => {
      // Support both camelCase (MemoryFileSystem) and snake_case (Legacy)
      const parentId = pt.payload.parentId || pt.payload.parent_id;

      if (parentId) {
        links.push({
          source: parentId,
          target: pt.id,
          type: 'REFINEMENT',
        });
      }
      if (pt.payload.source_ids) {
        // Handle semantic links (Weaver)
        // Weaver might store semantic links as separate points with category='link'
        // or as adjacency lists. Assuming standard Weaver format here.
        links.push({
          source: pt.payload.source_ids[0],
          target: pt.payload.source_ids[1],
          type: 'SEMANTIC',
        });
      }
    });

    const timestamp = Date.now();

    return {
      project: {
        id: 'proj_axiomatic_nest',
        name: 'Axiomatic Nest (Live)',
        domain: 'AI Cognition',
        description: 'Live view of the cognitive manifold.',
      },
      arrangements: [
        {
          id: `arr_live_${timestamp}`, // Unique ID per fetch
          projectId: 'proj_axiomatic_nest',
          name: `Snapshot ${new Date(timestamp).toLocaleTimeString()}`,
          createdAt: timestamp,
          container: { versionLabel: 'v3.0-nest', activeRules: [] },
          services: nodes,
          links: links,
          predicates: [],
        },
      ],
    };
  }
}
