import { Module } from '@nestjs/common';
import { RefinerService } from './refiner/refiner.service';
import { WeaverService } from './weaver/weaver.service';
import { MemoryFileSystemModule } from '../../infrastructure/memory/filesystem/filesystem.module';
import { DatabaseModule } from '../../infrastructure/database/database.module';

@Module({
  imports: [MemoryFileSystemModule, DatabaseModule],
  providers: [RefinerService, WeaverService],
  exports: [RefinerService, WeaverService],
})
export class CortexModule {}
