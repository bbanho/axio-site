import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { OllamaService } from '../../../infrastructure/ollama/ollama.service';
import { QdrantService } from '../../../infrastructure/qdrant/qdrant.service';
import { MemoryCacheService } from '../../../infrastructure/database/memory-cache.service';

@Injectable()
export class WeaverService {
  private readonly logger = new Logger(WeaverService.name);

  constructor(
    private readonly ollama: OllamaService,
    private readonly qdrant: QdrantService,
    private readonly memoryCache: MemoryCacheService,
  ) {}

  @Cron('*/45 * * * * *') // Every 45 seconds
  async handleCron() {
    await this.runWeaverCycle();
  }

  async runWeaverCycle() {
    this.logger.debug('Weaver scanning for patterns...');

    // Fix: Search by path prefix instead of status
    // Note: Qdrant doesn't support prefix match easily in filter unless we use a keyword field.
    // For now, we filter by category 'filesystem' and check path in code, or assume refined folder.
    // Better: Filter by parentId of the 'refined' folder if known, or iterate all filesystem items.
    // Given the constraints, let's look for items that have a path starting with /refined

    // Using a broader filter and checking path in memory for safety
    const points = await this.qdrant.scroll(
      {
        must: [{ key: 'category', match: { value: 'filesystem' } }],
        must_not: [
          { key: 'woven', match: { value: true } },
          { key: 'deleted', match: { value: true } },
        ],
      },
      10,
    );

    for (const point of points) {
      if (
        point.payload.path &&
        String(point.payload.path).startsWith('/refined')
      ) {
        try {
          await this.weave(point);
        } catch (e) {
          const errorMsg = e instanceof Error ? e.message : String(e);
          this.logger.error(`Failed to weave point ${point.id}: ${errorMsg}`);
        }
      }
    }
  }

  private async weave(point: any) {
    // Search for semantic neighbors
    const matches = await this.qdrant.search(
      point.vector,
      {
        must: [{ key: 'category', match: { value: 'filesystem' } }],
        must_not: [
          { has_id: [point.id] },
          { key: 'deleted', match: { value: true } },
        ],
      },
      5, // Check top 5
    );

    // Filter matches to only include /refined items
    const refinedMatches = matches.filter(
      (m) => m.payload.path && String(m.payload.path).startsWith('/refined'),
    );
    const topMatch = refinedMatches.find((m) => m.score > 0.5); // Lowered threshold drastically for debugging

    if (topMatch) {
      // Fetch full text content from SQLite cache using point IDs
      const memoryA = await this.memoryCache.findById(point.id);
      const memoryB = await this.memoryCache.findById(topMatch.id);

      if (!memoryA || !memoryB) {
        this.logger.warn(
          `Skipping weave for ${point.id}: missing content in cache`,
        );
        return;
      }

      const textA = memoryA.content;
      const textB = memoryB.content;

      this.logger.log(
        `Weaving ${point.payload.name} <-> ${topMatch.payload.name} (Score: ${topMatch.score})`,
      );

      const response = await this.ollama.chat(
        [
          {
            role: 'system',
            content:
              'Find logical connection between A and B. Output strictly: [RELATION_TYPE] explanation',
          },
          {
            role: 'user',
            content: `A: ${textA}\nB: ${textB}`,
          },
        ],
        { model: 'phi3:mini', temperature: 0.1 },
      );

      if (!response) {
        this.logger.warn(
          'Weaving aborted: Ollama chat failed (graceful degradation).',
        );
        return;
      }

      const id = this.qdrant.generateId();
      // Embed the relation description to place the link in semantic space
      const vector = await this.ollama.embed(response);

      if (!vector) {
        this.logger.warn(
          'Weaving aborted: Ollama embed failed (graceful degradation).',
        );
        return;
      }

      await this.qdrant.upsert([
        {
          id,
          vector,
          payload: {
            text: response, // relation description
            category: 'link', // Explicit category for links
            type: 'semantic_edge',
            source_ids: [point.id, topMatch.id],
            timestamp: Date.now(),
          },
        },
      ]);
      this.logger.log(`Link created: ${response.substring(0, 50)}...`);
    }

    // Mark woven regardless to avoid infinite loops
    await this.qdrant.updatePayload(
      { must: [{ has_id: [point.id] }] },
      { woven: true },
    );
  }
}
