import { Test, TestingModule } from '@nestjs/testing';
import { WeaverService } from './weaver.service';

describe('WeaverService', () => {
  let service: WeaverService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [WeaverService],
    }).compile();

    service = module.get<WeaverService>(WeaverService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
