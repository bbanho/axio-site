import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { v4 as uuidv4 } from 'uuid';
import { OllamaService } from '../../../infrastructure/ollama/ollama.service';
import { MemoryFileSystemService } from '../../../infrastructure/memory/filesystem/filesystem.service';
import { MemoryCacheService } from '../../../infrastructure/database/memory-cache.service';

@Injectable()
export class RefinerService {
  private readonly logger = new Logger(RefinerService.name);

  constructor(
    private readonly ollama: OllamaService,
    private readonly fileSystem: MemoryFileSystemService,
    private readonly memoryCache: MemoryCacheService,
  ) {}

  @Cron(CronExpression.EVERY_30_SECONDS)
  async handleCron() {
    this.logger.debug('Checking for raw memories...');
    const rawFiles = await this.fileSystem.ls('/raw');

    if (rawFiles.files.length === 0) return;

    for (const file of rawFiles.files) {
      await this.refine(file);
    }
  }

  private async refine(file: any) {
    try {
      const fileData = await this.fileSystem.read(`/raw/${file.name}`);
      const rawText = fileData.content;

      const refinedText = await this.ollama.chat(
        [
          {
            role: 'system',
            content: 'Summarize technically. Keep it dense and short.',
          },
          { role: 'user', content: rawText },
        ],
        { model: 'phi3:mini', temperature: 0.1 },
      );

      const newFilename = `refined_${Date.now()}_${file.name}`;
      const refinedFile = await this.fileSystem.write(
        `/refined/${newFilename}`,
        refinedText,
        {
          original_id: file.id,
          original_name: file.name,
          timestamp: Date.now(),
        },
      );

      // Also store the refined content in SQLite cache for Tri-Tier Memory
      // Generate a separate ID for the cache since we're having type issues with the file ID
      const cacheId = refinedFile?.id || uuidv4();
      if (refinedText) {
        await this.memoryCache.store(
          cacheId,
          refinedText,
          `/refined/${newFilename}`,
          newFilename,
        );
      }

      await this.fileSystem.delete(`/raw/${file.name}`);
      this.logger.log(
        `Refined ${file.name} -> ${newFilename} (cached in Tri-Tier Memory)`,
      );
    } catch (e) {
      this.logger.error(`Failed to refine ${file.name}`, e);
    }
  }
}
