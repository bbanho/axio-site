import { Test, TestingModule } from '@nestjs/testing';
import { RefinerService } from './refiner.service';

describe('RefinerService', () => {
  let service: RefinerService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [RefinerService],
    }).compile();

    service = module.get<RefinerService>(RefinerService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
