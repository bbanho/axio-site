import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';
import { OllamaService } from '../../infrastructure/ollama/ollama.service';
import { QdrantService } from '../../infrastructure/qdrant/qdrant.service';
import { MemoryCacheService } from '../../infrastructure/database/memory-cache.service';

@Injectable()
export class IngestionService implements OnModuleInit {
  private readonly logger = new Logger(IngestionService.name);
  // Hardcoded for now, ideal to move to ConfigService
  private readonly memoryDir =
    '/var/home/motto/Documentos/REPO/axiomatic-nest/memory';

  constructor(
    private readonly ollama: OllamaService,
    private readonly qdrant: QdrantService,
    private readonly memoryCache: MemoryCacheService,
  ) {}

  async onModuleInit() {
    this.logger.log('Ingestion Service Initialized');
    // Optional: Auto-ingest on startup? Or wait for command?
    // this.ingestAll();
  }

  async ingestAll() {
    if (!fs.existsSync(this.memoryDir)) {
      this.logger.error(`Memory directory not found: ${this.memoryDir}`);
      return;
    }

    const files = fs
      .readdirSync(this.memoryDir)
      .filter((f) => f.endsWith('.md'));
    this.logger.log(`Found ${files.length} memory files.`);

    let totalChunks = 0;

    for (const file of files) {
      const filePath = path.join(this.memoryDir, file);
      const content = fs.readFileSync(filePath, 'utf-8');
      const sections = this.parseSections(content);

      for (const section of sections) {
        const paragraphs = section.text.split(/\n\n+/);
        for (const para of paragraphs) {
          if (para.trim().length > 10) {
            await this.storeChunk(para.trim(), section.header, file);
            totalChunks++;
          }
        }
      }
    }
    this.logger.log(`Ingestion Complete. Processed ${totalChunks} chunks.`);
  }

  private parseSections(content: string): { header: string; text: string }[] {
    const lines = content.split('\n');
    const sections: { header: string; text: string }[] = [];
    let currentHeader = 'Root';
    let currentBuffer: string[] = [];

    for (const line of lines) {
      if (line.startsWith('#')) {
        if (currentBuffer.length > 0) {
          sections.push({
            header: currentHeader,
            text: currentBuffer.join('\n'),
          });
          currentBuffer = [];
        }
        currentHeader = line.replace(/#+\s*/, '').trim();
      } else {
        currentBuffer.push(line);
      }
    }
    if (currentBuffer.length > 0) {
      sections.push({ header: currentHeader, text: currentBuffer.join('\n') });
    }
    return sections;
  }

  private classifyContent(text: string, source: string): string {
    if (text.includes('[PM2]') || source.includes('error.log'))
      return 'system_log';
    if (text.includes('INSTRUCTION:')) return 'internal_thought';
    if (text.includes('HEARTBEAT_OK')) return 'heartbeat';
    return 'conversation';
  }

  private async storeChunk(text: string, context: string, sourceFile: string) {
    const category = this.classifyContent(text, sourceFile);
    const vectorText = `[Type: ${category}] [File: ${sourceFile}] [Topic: ${context}] ${text}`;

    try {
      const vector = await this.ollama.embed(vectorText);
      if (!vector) {
        this.logger.warn(
          `Skipping chunk from ${sourceFile}: Ollama unavailable`,
        );
        return;
      }
      const id = this.qdrant.generateId();

      // Store full text content in SQLite cache
      await this.memoryCache.store(
        id,
        text,
        context, // Use context as path for now
        sourceFile,
      );

      // Store only embedding and metadata in Qdrant (without full text payload)
      await this.qdrant.upsert([
        {
          id,
          vector,
          payload: {
            context,
            source: sourceFile,
            category,
            timestamp: Date.now(),
            status: 'raw',
            // Note: 'text' field removed to save space and avoid redundancy
          },
        },
      ]);

      this.logger.debug(
        `Stored chunk ${id} from ${sourceFile} in Tri-Tier Memory`,
      );
    } catch (e) {
      this.logger.error(`Failed to store chunk from ${sourceFile}: ${e}`);
    }
  }
}
