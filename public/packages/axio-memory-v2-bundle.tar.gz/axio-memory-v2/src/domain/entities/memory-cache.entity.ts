import {
  Entity,
  Column,
  PrimaryColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity('memory_cache')
export class MemoryCache {
  @PrimaryColumn()
  id!: string; // The Qdrant Point ID

  @Column({ type: 'text' })
  content!: string; // The full Markdown content

  @Column({ nullable: true })
  path?: string; // Physical or virtual path

  @Column({ nullable: true })
  source?: string; // Originating file

  @CreateDateColumn()
  createdAt!: Date;

  @UpdateDateColumn()
  updatedAt!: Date;
}
