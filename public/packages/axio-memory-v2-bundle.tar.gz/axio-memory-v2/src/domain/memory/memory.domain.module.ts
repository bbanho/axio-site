import { Module } from '@nestjs/common';
import { MemoryDomainService } from './memory.domain.service';
import { MemoryFileSystemModule } from '../../infrastructure/memory/filesystem/filesystem.module';

@Module({
  imports: [MemoryFileSystemModule],
  providers: [MemoryDomainService],
  exports: [MemoryDomainService],
})
export class MemoryDomainModule {}
