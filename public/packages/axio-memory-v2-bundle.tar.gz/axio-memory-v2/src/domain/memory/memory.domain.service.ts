import { Injectable } from '@nestjs/common';
import { MemoryFileSystemService } from '../../infrastructure/memory/filesystem/filesystem.service';

export interface MemoryItem {
  id: string;
  content: any;
  category: string;
  tags?: string[];
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface MemoryCategory {
  path: string;
  name: string;
  itemCount: number;
  lastModified: Date;
}

@Injectable()
export class MemoryDomainService {
  constructor(private readonly fileSystemService: MemoryFileSystemService) {}

  async storeMemory(
    category: string,
    itemName: string,
    content: any,
    options?: {
      tags?: string[];
      metadata?: Record<string, any>;
    },
  ): Promise<MemoryItem> {
    const path = `/${category}/${itemName}`;

    const payload = {
      category,
      tags: options?.tags || [],
      metadata: options?.metadata || {},
    };

    const file = await this.fileSystemService.writeFile(path, content, payload);

    return {
      id: file.id,
      content: file.content,
      category: payload.category,
      tags: payload.tags,
      metadata: payload.metadata,
      createdAt: file.createdAt,
      updatedAt: file.updatedAt,
    };
  }

  async retrieveMemory(
    category: string,
    itemName: string,
  ): Promise<MemoryItem> {
    const path = `/${category}/${itemName}`;
    const result = await this.fileSystemService.read(path);

    return {
      id: result.metadata.id,
      content: result.content,
      category: result.metadata.payload.category,
      tags: result.metadata.payload.tags || [],
      metadata: result.metadata.payload.metadata || {},
      createdAt: result.metadata.createdAt,
      updatedAt: result.metadata.updatedAt,
    };
  }

  async listCategories(): Promise<MemoryCategory[]> {
    const rootList = await this.fileSystemService.ls('/');
    const categories: MemoryCategory[] = [];

    for (const folder of rootList.folders) {
      const categoryList = await this.fileSystemService.ls(folder.path);
      categories.push({
        path: folder.path,
        name: folder.name,
        itemCount: categoryList.files.length,
        lastModified: folder.updatedAt,
      });
    }

    return categories.sort(
      (a, b) => b.lastModified.getTime() - a.lastModified.getTime(),
    );
  }

  async listMemoriesInCategory(category: string): Promise<MemoryItem[]> {
    const path = `/${category}`;
    const categoryList = await this.fileSystemService.ls(path);

    const memories: MemoryItem[] = [];

    for (const file of categoryList.files) {
      const memory = await this.retrieveMemory(category, file.name);
      memories.push(memory);
    }

    return memories.sort(
      (a, b) => b.updatedAt.getTime() - a.updatedAt.getTime(),
    );
  }

  async createCategory(categoryPath: string): Promise<void> {
    await this.fileSystemService.mkdir(categoryPath);
  }

  async searchMemories(
    query: string,
    category?: string,
  ): Promise<MemoryItem[]> {
    if (category) {
      const memories = await this.listMemoriesInCategory(category);
      return this.filterMemoriesByQuery(memories, query);
    } else {
      const categories = await this.listCategories();
      const allMemories: MemoryItem[] = [];

      for (const cat of categories) {
        const memories = await this.listMemoriesInCategory(cat.name);
        allMemories.push(...memories);
      }

      return this.filterMemoriesByQuery(allMemories, query);
    }
  }

  async deleteMemory(category: string, itemName: string): Promise<void> {
    const path = `/${category}/${itemName}`;
    await this.fileSystemService.delete(path);
  }

  async deleteCategory(category: string): Promise<void> {
    const path = `/${category}`;
    await this.fileSystemService.delete(path);
  }

  async memoryExists(category: string, itemName: string): Promise<boolean> {
    const path = `/${category}/${itemName}`;
    return this.fileSystemService.fileExists(path);
  }

  async categoryExists(category: string): Promise<boolean> {
    const path = `/${category}`;
    return this.fileSystemService.folderExists(path);
  }

  private filterMemoriesByQuery(
    memories: MemoryItem[],
    query: string,
  ): MemoryItem[] {
    const lowerQuery = query.toLowerCase();

    return memories.filter((memory) => {
      const contentMatch =
        typeof memory.content === 'string'
          ? memory.content.toLowerCase().includes(lowerQuery)
          : JSON.stringify(memory.content).toLowerCase().includes(lowerQuery);

      const tagsMatch = memory.tags?.some((tag) =>
        tag.toLowerCase().includes(lowerQuery),
      );

      const metadataMatch = memory.metadata
        ? Object.values(memory.metadata).some(
            (value) =>
              typeof value === 'string' &&
              value.toLowerCase().includes(lowerQuery),
          )
        : false;

      return contentMatch || tagsMatch || metadataMatch;
    });
  }
}
